# Attendance-Tracker-App
Designed and built an App on Android Studio with Java and SQLite.
## Main Features of the App:
1. Shows Today's Classes on the main screen of app.
2. Keeps track of your attendance by simply submitting your daily attendance.
3. Shows your current Attendance Percent for all courses
4. Shows weekly Timetable.
5. You can manually set your own timetable, it's a bit boring, but it is just one time.

Link to download the app is:  
APK: http://bit.ly/75_percent
This app is in its very early stage, I will keep updating it with time.

# Screenshots of App
<img src="https://github.com/yogeshknp/Attendance-Tracker-App/blob/master/App%20Screenshots/64639237_358926091447276_1878572717645496320_n.png" width="250" margin="50px" />      <img src="https://github.com/yogeshknp/Attendance-Tracker-App/blob/master/App%20Screenshots/67194994_397516860871001_8425104759475666944_n.png" width="250" margin="5px" />

<img src="https://github.com/yogeshknp/Attendance-Tracker-App/blob/master/App%20Screenshots/67402075_485884945499162_922742254320222208_n.png" width="250" padding="5px" />       <img src="https://github.com/yogeshknp/Attendance-Tracker-App/blob/master/App%20Screenshots/67436279_360081861339008_8906345524186054656_n.png" width="250" padding="5px" />
